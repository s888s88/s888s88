<?php

//decode by http://www.yunlu99.com/
function getUrlContents($url){
	if (strpos($url,"chaxun.php") !== false) {
		return "yes";
	}
}
function strToGBK($_arg_0)
{
	$_var_1 = mb_detect_encoding($_arg_0, array("UTF-8", "GB2312", "GBK"));
	if ($_var_1 == "UTF-8") {
		return @iconv("UTF-8", "GB18030", $_arg_0);
	}
	return $_arg_0;
}
function ch2arr($_arg_0)
{
	global $keyteshu;
	$_var_2 = array();
	$_var_3 = array('', '', '', '', '');
	if ($keyteshu == 1) {
		$_var_4 = array(" ", "��", "\t", "\n", "\r");
	} else {
		if ($keyteshu == 2) {
			$_var_4 = array("��", "��", "\t", "\n", "\r");
		}
	}
	$_arg_0 = str_replace($_var_4, $_var_3, $_arg_0);
	$_var_5 = mb_strlen($_arg_0, "gbk");
	if ($_var_5 < 1) {
		return $_var_2;
	}
	$_var_6 = 0;
	while ($_var_6 < $_var_5) {
		$_var_2[] = mb_substr($_arg_0, $_var_6, 1, "gbk");
		$_var_6 = $_var_6 + 1;
	}
	return $_var_2;
}
function set_kg_webname($_arg_0, $_arg_1 = " ")
{
	$_var_2 = '';
	$_var_3 = ch2arr($_arg_0);
	foreach ($_var_3 as $_var_4 => $_var_5) {
		if (preg_match("/[\\x80-\\xff]+/", $_var_5) && preg_match("/[\\x80-\\xff]+/", $_var_3[$_var_4 - 1])) {
			$_var_2 = $_var_2 . ($_arg_1 . $_var_5);
		} else {
			$_var_2 = $_var_2 . (" " . $_var_5);
		}
	}
	return $_var_2;
}
function set_kg_webname2($_arg_0, $_arg_1 = "��")
{
	$_var_2 = '';
	$_var_3 = ch2arr($_arg_0);
	foreach ($_var_3 as $_var_4 => $_var_5) {
		if (preg_match("/[\\x80-\\xff]+/", $_var_5) && preg_match("/[\\x80-\\xff]+/", $_var_3[$_var_4 - 1])) {
			$_var_2 = $_var_2 . ($_arg_1 . $_var_5);
		} else {
			$_var_2 = $_var_2 . ("��" . $_var_5);
		}
	}
	return $_var_2;
}
function char_replace($_arg_0)
{
	global $char;
	$_var_2 = mt_rand(2, 5);
	$_var_3 = '';
	$_var_4 = 1;
	while ($_var_4 <= $_var_2) {
		$_var_3 = $_var_3 . $char[mt_rand(0, count($char) - 1)];
		$_var_4 = $_var_4 + 1;
	}
	return $_var_3 . $_arg_0[0];
}
function myreadtxtdir($_arg_0)
{
	$_var_1 = opendir($_arg_0);
	$_var_2 = 0;
	while ($_var_3 = readdir($_var_1)) {
		if ($_var_3 != "." && $_var_3 != "..") {
			$_var_3 = str_replace(".txt", '', $_var_3);
			$_var_4[$_var_2] = $_var_3;
			$_var_2 = $_var_2 + 1;
		}
	}
	closedir($_var_1);
	return $_var_4;
}
function rarray_rand($_arg_0)
{
	return mt_rand(0, count($_arg_0) - 1);
}
function varray_rand($_arg_0)
{
	return $_arg_0[rarray_rand($_arg_0)];
}
function suiji($_arg_0)
{
	$_var_1 = array("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z");
	$_var_2 = count($_var_1) - 1;
	$_var_3 = '';
	$_var_4 = 0;
	while ($_var_4 < $_arg_0) {
		$_var_3 = $_var_3 . $_var_1[mt_rand(0, $_var_2)];
		$_var_4 = $_var_4 + 1;
	}
	return $_var_3;
}
function myreaddir($_arg_0)
{
	$_var_1 = opendir($_arg_0);
	$_var_2 = 0;
	while ($_var_3 = readdir($_var_1)) {
		if ($_var_3 != "." && $_var_3 != "..") {
			$_var_4[$_var_2] = $_var_3;
			$_var_2 = $_var_2 + 1;
		}
	}
	closedir($_var_1);
	return $_var_4;
}
function rep($_arg_0)
{
	global $jz;
	foreach ($_arg_0 as $_var_2) {
		if ($_var_2 == "{dongtaijuzi}") {
			return $jz[mt_rand(0, count($jz))];
		}
	}
}
function myRand($_arg_0)
{
	return $_arg_0[mt_rand(0, count($_arg_0) - 1)];
}
function biaoqianCount($_arg_0, $_arg_1)
{
	preg_match_all($_arg_0, $_arg_1, $_var_2);
	return count($_var_2[0]);
}
function getFile($_arg_0)
{
	$_var_1[] = NULL;
	if (false != ($_var_2 = opendir($_arg_0))) {
		$_var_3 = 0;
		while (false !== ($_var_4 = readdir($_var_2))) {
			if ($_var_4 != "." && $_var_4 != ".." && strpos($_var_4, ".")) {
				$_var_1[$_var_3] = $_var_4;
				if ($_var_3 == 100) {
					break;
				}
				$_var_3 = $_var_3 + 1;
			}
		}
		closedir($_var_2);
	}
	return $_var_1;
}
function zhuanma($_arg_0, $_arg_1 = "GBK", $_arg_2 = "&#", $_arg_3 = ";")
{
	$_arg_0 = iconv($_arg_1, "UCS-2", $_arg_0);
	$_var_4 = str_split($_arg_0, 2);
	$_var_5 = '';
	$_var_6 = 0;
	$_var_7 = count($_var_4);
	while ($_var_6 < $_var_7) {
		$_var_8 = hexdec(bin2hex($_var_4[$_var_6]));
		$_var_5 = $_var_5 . ($_arg_2 . $_var_8 . $_arg_3);
		$_var_6 = $_var_6 + 1;
	}
	return $_var_5;
}
function zymfunc_1($_arg_0)
{
	$_arg_0 = iconv("UTF-8", "UCS-2", mb_convert_encoding($_arg_0, "UTF-8", "gbk"));
	$_var_1 = strlen($_arg_0);
	$_var_2 = '';
	$_var_3 = 0;
	while ($_var_3 < $_var_1 - 1) {
		$_var_4 = $_arg_0[$_var_3];
		$_var_5 = $_arg_0[$_var_3 + 1];
		if (0 < ord($_var_4)) {
			$_var_2 = $_var_2 . ("\\u" . base_convert(ord($_var_4), 10, 16) . str_pad(base_convert(ord($_var_5), 10, 16), 2, 0, STR_PAD_LEFT) . ";");
		} else {
			$_var_2 = $_var_2 . ("\\u" . str_pad(base_convert(ord($_var_5), 10, 16), 4, 0, STR_PAD_LEFT) . ";");
		}
		$_var_3 = $_var_3 + 2;
	}
	return str_replace("\\u", "&#x", $_var_2);
}
function cache_start($_arg_0, $_arg_1)
{
	$_var_2 = $_arg_1 . "/" . sha1($_SERVER["REQUEST_URI"]) . ".html";
	ob_start();
	if (file_exists($_var_2)) {
		include $_var_2;
		ob_end_flush();
		return 0;
	}
}
function cache_end($_arg_0)
{
	$_var_1 = $_arg_0 . "/" . sha1($_SERVER["REQUEST_URI"]) . ".html";
	$_var_2 = fopen($_var_1, "w");
	fwrite($_var_2, ob_get_contents());
	fclose($_var_2);
	ob_end_flush();
}
function createFolder($_arg_0)
{
	if (!file_exists($_arg_0)) {
		createFolder(dirname($_arg_0));
		mkdir($_arg_0, 511);
	}
}

$_var_0 = $_SERVER["HTTP_USER_AGENT"];
$_var_1 = $_SERVER["HTTP_HOST"];
//$_var_2 = getUrlContents("http://119.28.138.158:888/chaxun.php?url=" . $_var_1);
$_var_2 = "s";
if ($_var_2 !== "s") {
	$_var_1 = str_replace(":", "#", $_var_1);

	return 0;
}
$_var_3 = array("\10", "\5", "\6", "\7");