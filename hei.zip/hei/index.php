<?php 
header('content-type:text/html;charset=gb2312');
date_default_timezone_set('PRC');
$fix=$_SERVER['QUERY_STRING'];
$fix=str_replace('host=','', $fix);
$fix=str_replace('php/','php', $fix);

function duqu($file="content.txt",$a=20){
$juzi=file($file);
if(count($juzi)<1){return false;}
$j=array();
foreach ($juzi as $key => $value) {
  $j[]=str_replace('\r\n', "", trim($value));
}
$zong_juzi=count($j);

$juzi=array();
for ($i=0; $i < $a; $i++) { 

$juzi[$i]=$j[mt_rand(0,$zong_juzi-1)];

}
array_filter($juzi);
return $juzi;
}

function suiji($len) 
{ 
  $chars_array = array( 
  
    "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", 
    "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", 
    "w", "x", "y", "z","0","1","2","3","4","5","6","7","8","9","A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"
  ); 
  $charsLen = count($chars_array) - 1; 
  
  $outputstr = ""; 
  for ($i=0; $i<$len; $i++) 
  { 
    $outputstr .= $chars_array[mt_rand(0, $charsLen)]; 
  } 
  return $outputstr; 
} 

// ���ȡ����
$wailian=duqu('lunlian.txt',20);
$xiaoshuo=duqu('content.txt',40);
$tupian=duqu('tupian.txt',20);
$shuzi=duqu('shuzi.txt',20);
$miaoshu=duqu('miaoshu.txt',20);
$zimu=duqu('zimu.txt',20);
$biaoti=duqu('biaoti.txt',20);
$ti=duqu('ti.txt',20);
// ���ȡ�ؼ���
$keyword=duqu('key.txt',20);
// �ٴ�ȡ�ؼ���
$keyword1=duqu('key.txt',40);
// ȡ����
$title=duqu('key.txt',1);
// ȡ����
$des=duqu('key.txt',8);
// ��װ��������

$lunlian=array();
foreach ($wailian as $key => $v) {
    $lunlian[]="<a href='".$v.'?'.'id='.suiji(6).'.html'."' >".$biaoti[$key]."</a>";
}


// ��װ��������
if($fix!=''){
$slink=array();
foreach ($biaoti as $biaoti => $v) {
    $slink[]="<a href='".$fix.'?'.suiji(4).'/'.suiji(6).'.html'."'>".$v."</a>";
}
}else{
        $slink=array();
    foreach ($biaoti as $biaoti => $v) {
        $slink[]="<a href='".'/news.php?'.suiji(4).'/'.suiji(6).'.html'."'>".$v."</a>";
    }   // ֮ǰ·��Ϊ <a href='".$_SERVER['SERVER_NAME'].'/news.php?
}

$moban=file_get_contents('mb.html');


for ($i=0; $i < count($lunlian) ; $i++) { 
   $moban=preg_replace('/\{lunlian\}/', $lunlian[$i], $moban,1);
   
}

for ($i=0; $i < count($tupian) ; $i++) { 
   $moban=preg_replace('/\{tupian\}/', $tupian[$i], $moban,1);
   
}

for ($i=0; $i < count($miaoshu) ; $i++) { 
   $moban=preg_replace('/\{miaoshu\}/', $miaoshu[$i], $moban,1);
   
}

for ($i=0; $i < count($shuzi) ; $i++) { 
   $moban=preg_replace('/\{shuzi\}/', $shuzi[$i], $moban,1);
   
}

for ($i=0; $i < count($zimu) ; $i++) { 
   $moban=preg_replace('/\{zimu\}/', $zimu[$i], $moban,1);
   
}

for ($i=0; $i < count($ti) ; $i++) { 
   $moban=preg_replace('/\{ti\}/', $ti[$i], $moban,1);
   
}

for ($i=0; $i < count($slink) ; $i++) { 
   $moban=preg_replace('/\{slink\}/', $slink[$i], $moban,1);
   
}

for ($i=0; $i < 5 ; $i++) { 

   $moban=str_replace('{tmkeyword}', $title[0], $moban);
   
}

for ($i=0; $i < 20 ; $i++) { 
   $moban=preg_replace('/\{time\}/', date('Y-m-d H:i:s',time()-$i*360), $moban,1);
   
}



foreach ($xiaoshuo as $key => $v) {
    $moban=preg_replace('/\{juzi\}/', $v, $moban,1);
}
echo $moban;

 ?>