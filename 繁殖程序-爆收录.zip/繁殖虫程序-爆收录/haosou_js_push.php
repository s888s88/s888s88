<script>(function(){
   var src = document.location.protocol +'//js.passport.qihucdn.com/11.0.1.js?0cafbe109ab248eb7be06d7f99c4009f';
   document.write('<script src="' + src + '" id="sozz"><\/script>');
})();</script>
