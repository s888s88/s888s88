<?php
//����ַ�����
function suiji($len) 
{ 
  $chars_array = array( 
  
    "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", 
    "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", 
    "w", "x", "y", "z","0","1","2","3","4","5","6","7","8","9","A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"
  ); 
  $charsLen = count($chars_array) - 1; 
  
  $outputstr = ""; 
  for ($i=0; $i<$len; $i++) 
  { 
    $outputstr .= $chars_array[mt_rand(0, $charsLen)]; 
  } 
  return $outputstr; 
} 
//������Ų���
function suijifuhao($fuhao) 
{ 
  $sjfh_array = array( 
  
    "", "", "", ""
  ); 
  $sjfhLen = count($sjfh_array) - 1; 
  
  $zifujiegou = ""; 
  for ($i=0; $i<$fuhao; $i++) 
  { 
    $zifujiegou .= $sjfh_array[mt_rand(0, $sjfhLen)]; 
  } 
  return $zifujiegou; 
} 
//��ȡĿ¼�������ļ���
function myreaddir($dir) {
$handle=opendir($dir);
$i=0;
while($file=readdir($handle)) {
if (($file!=".")and($file!="..")) {
$list[$i]=$file;
$i=$i+1;
}
}
closedir($handle); 
return $list;
}

//�滻�ص�����
function rep($match){
  global $jz;
  foreach($match as $v){
       
	   switch($v){
	   
		  case '{dongtaijuzi}':return $jz[mt_rand(0,count($jz))];break;
	   }

   }
}

//�����ȡһ������
function myRand($arr){
    
	return $arr[mt_rand(0,count($arr)-1)];
}

//ȡ��ǩ��������
function biaoqianCount($reg,$moban){
preg_match_all($reg,$moban,$count);

return count($count[0]);

}

//��ȡ�ļ��б�
function getFile($dir) {
    $fileArray[]=NULL;
    if (false != ($handle = opendir ( $dir ))) {
        $i=0;
        while ( false !== ($file = readdir ( $handle )) ) {
            //ȥ��"��.������..���Լ�����.xxx����׺���ļ�
            if ($file != "." && $file != ".."&&strpos($file,".")) {
                $fileArray[$i]=$file;
                if($i==100){
                    break;
                }
                $i++;
            }
        }
        //�رվ��
        closedir ( $handle );
    }
    return $fileArray;
}
//ת�뺯��
function zhuanma( $_obfuscate_R2_b, $_obfuscate_4dDCn5lFjwg = "GBK", $_obfuscate_9W0r1l = "&#", $_obfuscate_YYcb2NK5qw = ";" )
{
    $_obfuscate_R2_b = iconv( $_obfuscate_4dDCn5lFjwg, "UCS-4", $_obfuscate_R2_b );
    $_obfuscate_EHIqKhHv = str_split( $_obfuscate_R2_b, 4 );
    $_obfuscate_YjAxSArm = "";
    $_obfuscate_7w = 0;
    $_obfuscate_mc2H = count( $_obfuscate_EHIqKhHv );
    for ( ; $_obfuscate_7w< $_obfuscate_mc2H; ++$_obfuscate_7w)
    {
        $_obfuscate_e4vB = hexdec( bin2hex( $_obfuscate_EHIqKhHv[$_obfuscate_7w] ) );
        $_obfuscate_YjAxSArm .= $_obfuscate_9W0r1l.$_obfuscate_e4vB.$_obfuscate_YYcb2NK5qw;
    }
    return $_obfuscate_YjAxSArm;
}
//���溯��
function cache_start($_time, $dir)
{
  $cachefile = $dir.'/'.sha1($_SERVER['REQUEST_URI']).'.html';
  ob_start();
  if(file_exists($cachefile))
  {
    include($cachefile);
    ob_end_flush();
    exit;
  }
}
function cache_end($dir)
{
  $cachefile = $dir.'/'.sha1($_SERVER['REQUEST_URI']).'.html';
  $fp = fopen($cachefile, 'w');
  fwrite($fp, ob_get_contents());
  fclose($fp);
  ob_end_flush();
}

function createFolder($path) 
{ 
if (!file_exists($path)) 
{ 
createFolder(dirname($path)); 
mkdir($path, 0777); 
} 
}